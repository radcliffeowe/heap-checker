

public class HeapChecker {
	public boolean addEltTester(IHeap hOrig, int elt, IBinTree hAdded) {
		return hAdded.isHeap(0, hAdded) && 
				hAdded.containsAllElements(hOrig, elt, hAdded) &&
				hAdded.hasBeenAdded(hOrig, elt, hAdded) &&
				hAdded.noNewElements(hOrig, elt, hAdded);	
	}

	public boolean remMinEltTester(IHeap hOrig, IBinTree hRemoved) {
		return hRemoved.isHeap(0, hRemoved) &&
				hOrig.containsAllElementsRemoved(hOrig, hRemoved) &&
				hOrig.hasBeenRemoved(hOrig, hRemoved) &&
				hRemoved.noNewElementsRemoved(hOrig, hRemoved);
	}
}
