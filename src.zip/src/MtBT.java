import java.util.LinkedList;

class MtBT implements IBinTree {
	MtBT(){}

	// returns false since empty tree has no elements
	public boolean hasElt(int e) {
		return false;
	}

	// returns 0 since enpty tree has no elements
	public int size() {
		return 0;
	}

	// returns 0 since empty tree has no branches
	public int height() {
		return 0;
	}

	/**
	 * @param root The value of the node above another node in the same branch
	 * @param hAdded The new binary tree produced after running addElt()
	 * @return True if hAdded is an empty binary tree
	 */
	public boolean isHeap(int root, IBinTree hAdded) {
		if(hAdded.extractData(new LinkedList<Integer>()).isEmpty()) {
			return true;
		}
		else return false;
	}

	/**
	 * @param e The integer that you want to count
	 * @return 0, since no matter what e is, there are still no data in an empty BT, so it does not occur at all
	 */
	public int countOccurences(int e) {
		return 0;
	}

	/**
	 * @param hOriginal Your original heap before you add an element to it
	 * @param elt The element you added to the IHeap
	 * @param hAdded Your resulting binary tree, after adding elt to the IHeap
	 * @return True if the given heap is empty and the resulting binary tree consists only of the added elt
	 */
	public boolean containsAllElements(IHeap hOriginal, int elt, IBinTree hAdded) {
		LinkedList<Integer> heapData = hOriginal.extractData(new LinkedList<Integer>());
		LinkedList<Integer> binTreeData = hAdded.extractData(new LinkedList<Integer>());
		binTreeData.add(elt);
		if(heapData.isEmpty() && binTreeData.size()== 1) {
			return true;
		}
		else return false;
	}

	/**
	 * @param data A LinkedList consisting of the values in the nodes the method has run on so far
	 * @return A LinkedList consisting of all the integer values in a given binary tree
	 */
	public LinkedList<Integer> extractData(LinkedList<Integer> data){

		return data;	
	}

	/**
	 * @param hOriginal Your original heap before you add an element to it
	 * @param elt The element you added to the IHeap
	 * @param hAdded Your resulting binary tree, after adding elt to the IHeap
	 * @return False, because if the binary tree is empty, then you have not added an elt to it
	 */
	public boolean hasBeenAdded(IHeap hOriginal, int elt, IBinTree hAdded) {
		return false;

	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param hRemoved The resulting binary tree after removing the min elt from hOriginal
	 * @return True, if the min elt of the IHeap has been removed once from IBinTree
	 */
	public boolean hasBeenRemoved(IHeap hOriginal, IBinTree hRemoved) {
		LinkedList<Integer> heapData = hOriginal.extractData(new LinkedList<Integer>());
		LinkedList<Integer> binTreeData = hRemoved.extractData(new LinkedList<Integer>());
		if((heapData.size() == 1 && binTreeData.isEmpty()) || heapData.isEmpty()) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param elt The element you added to the IHeap
	 * @param hAdded Your resulting binary tree, after adding elt to the IHeap
	 * @return True since if IBinTree is empty, then no elements in it could have not occurred in IHeap
	 */
	public boolean noNewElements(IHeap hOriginal, int elt, IBinTree hAdded) {
		return true;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param hRemoved The resulting binary tree after removing the min elt from hOriginal
	 * @return True if every elt in hOriginal also occurs in hRemoved, the appropriate number of times
	 */
	public boolean containsAllElementsRemoved(IHeap hOriginal, IBinTree hRemoved) {
		LinkedList<Integer> heapData = hOriginal.extractData(new LinkedList<Integer>());
		if(heapData.size() == 1 || heapData.isEmpty()) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param hRemoved The resulting binary tree after removing the min elt from hOriginal
	 * @return True since if IBinTree is empty, then no elements in it could have not occurred in IHeap
	 */
	public boolean noNewElementsRemoved(IHeap hOriginal, IBinTree hRemoved) {
		return true;
	}

}