import java.util.LinkedList;

class DataBT implements IBinTree {
	int data;
	IBinTree left;
	IBinTree right;

	DataBT(int data, IBinTree left, IBinTree right) {
		this.data = data;
		this.left = left;
		this.right = right;
	}

	// an alternate constructor for when both subtrees are empty
	DataBT(int data) {
		this.data = data;
		this.left = new MtBT();
		this.right = new MtBT();
	}

	// determines whether this node or node in subtree has given element
	public boolean hasElt(int e) {
		return this.data == e || this.left.hasElt(e) || this.right.hasElt(e) ;
	}

	// adds 1 to the number of nodes in the left and right subtrees
	public int size() {
		return 1 + this.left.size() + this.right.size();
	}

	// adds 1 to the height of the taller subtree
	public int height() {
		return 1 + Math.max(this.left.height(), this.right.height());
	}

	/**
	 * @param rootParam The value of the node above another node in the same branch
	 * @param hAdded The new binary tree produced after running addElt()
	 * @return True if hAdded is a heap, else false
	 */
	public boolean isHeap(int rootParam, IBinTree hAdded) {

		// is root smaller than rest of heap?
		if(this.data <= rootParam) {
			return false;
		}
		else {
			rootParam = this.data;

			return this.left.isHeap(rootParam, this.left) && this.right.isHeap(rootParam, this.right); 
		}
	}
	/**
	 * @param e The integer that you want to count
	 * @return The number of times e appears in a given binary tree
	 */
	public int countOccurences(int e) {
		if(this.data == e) {
			return 1 + this.left.countOccurences(e) + this.right.countOccurences(e);
		}
		else {
			return this.left.countOccurences(e) + this.right.countOccurences(e);
		}
	}
	
	/**
	 * @param data A LinkedList consisting of the values in the nodes the method has run on so far
	 * @return A LinkedList consisting of all the integer values in a given binary tree
	 */
	public LinkedList<Integer> extractData(LinkedList<Integer> data){

		data.add(this.data);
		this.left.extractData(data);
		this.right.extractData(data);
		return data;
	}

	/**
	 * @param hOriginal Your original heap before you add an element to it
	 * @param elt The element you added to the IHeap
	 * @param hAdded Your resulting binary tree, after adding elt to the IHeap
	 * @return True if hAdded contains all the elements from hOriginal, the same number of times
	 */
	public boolean containsAllElements(IHeap hOriginal, int elt, IBinTree hAdded) {

		LinkedList<Integer> heapData = hOriginal.extractData(new LinkedList<Integer>());
		int totalTrue = 0;

		for(int datumPiece : heapData) {
			if (datumPiece == elt) {
				if(hOriginal.countOccurences(datumPiece) == (hAdded.countOccurences(datumPiece)-1)) {
					totalTrue++;
				}
			}
			else {
				if(hOriginal.countOccurences(datumPiece) == (hAdded.countOccurences(datumPiece))) {
					totalTrue++;
				}
			}
		}
		if(totalTrue == heapData.size()) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you add an element to it
	 * @param elt The element you added to the IHeap
	 * @param hAdded Your resulting binary tree, after adding elt to the IHeap
	 * @return True if the added elt appears in hAdded the appropriate number of times
	 */
	public boolean hasBeenAdded(IHeap hOriginal, int elt, IBinTree hAdded) {
		if((hOriginal.countOccurences(elt)+1) == hAdded.countOccurences(elt)) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param hRemoved The resulting binary tree after removing the min elt from hOriginal
	 * @return True if the min elt has been removed once
	 */
	public boolean hasBeenRemoved(IHeap hOriginal, IBinTree hRemoved) {
		int elt = this.data;
		if(hOriginal.countOccurences(elt) == (hRemoved.countOccurences(elt)+1)) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param elt The element you added to the IHeap
	 * @param hAdded Your resulting binary tree, after adding elt to the IHeap
	 * @return True if every element in hAdded occurs the appropriate number of times in hOriginal
	 */
	public boolean noNewElements(IHeap hOriginal, int elt, IBinTree hAdded) {

		LinkedList<Integer> binTreeData = hAdded.extractData(new LinkedList<Integer>());
		int totalTrue = 0;

		for(int datumPiece : binTreeData) {
			if (datumPiece == elt) {
				if(hOriginal.countOccurences(datumPiece) == (hAdded.countOccurences(datumPiece)-1)) {
					totalTrue++;
				}
			}
			else {
				if(hOriginal.countOccurences(datumPiece) == (hAdded.countOccurences(datumPiece))) {
					totalTrue++;
				}
			}
		}
		if(totalTrue == binTreeData.size()) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param hRemoved The resulting binary tree after removing the min elt from hOriginal
	 * @return True if every elt in hOriginal also occurs in hRemoved, the appropriate number of times
	 */
	public boolean containsAllElementsRemoved(IHeap hOriginal, IBinTree hRemoved) {

		int elt = this.data;
		LinkedList<Integer> heapData = hOriginal.extractData(new LinkedList<Integer>());
		int totalTrue = 0;

		for(int datumPiece : heapData) {
			if (datumPiece == elt) {
				if(hOriginal.countOccurences(datumPiece)-1 == (hRemoved.countOccurences(datumPiece))) {
					totalTrue++;
				}
			}
			else {
				if(hOriginal.countOccurences(datumPiece) == (hRemoved.countOccurences(datumPiece))) {
					totalTrue++;
				}
			}
		}
		if(totalTrue == heapData.size()) {
			return true;
		}
		else return false;
	}

	/**
	 * @param hOriginal Your original heap before you remove the minimum element from it
	 * @param hRemoved The resulting binary tree after removing the min elt from hOriginal
	 * @return True if there are no elts in hRemoved that did not occur the same number of times in hOriginal
	 */
	public boolean noNewElementsRemoved(IHeap hOriginal, IBinTree hRemoved) {

		int elt = this.data;
		LinkedList<Integer> binTreeData = hRemoved.extractData(new LinkedList<Integer>());
		int totalTrue = 0;

		for(int datumPiece : binTreeData) {
			if (datumPiece == elt) {
				if(hOriginal.countOccurences(datumPiece) == (hRemoved.countOccurences(datumPiece))) {
					totalTrue++;
				}
			}
			else {
				if(hOriginal.countOccurences(datumPiece) == (hRemoved.countOccurences(datumPiece))) {
					totalTrue++;
				}
			}
		}
		if(totalTrue == binTreeData.size()) {
			return true;
		}
		else return false;
	}


}
