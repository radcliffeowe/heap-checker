import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;

import org.junit.Test;

public class Examples {
	
	public Examples() {}
	
	HeapChecker HT = new HeapChecker();
	
	MtBT mtBT = new MtBT();
	DataBT four = new DataBT(4);
	DataBT six = new DataBT(6);
	DataBT five = new DataBT(5);
	DataBT seven = new DataBT(7);
	DataBT two = new DataBT(2, four, six);
	DataBT three = new DataBT(3, five, seven);
	DataBT one = new DataBT(1, two, three);
	
	DataBT oneScramble = new DataBT(1);
	DataBT twoScramble = new DataBT(2);
	DataBT threeScramble = new DataBT(3);
	DataBT fourScramble = new DataBT(4);
	DataBT fiveScramble = new DataBT(5, oneScramble, twoScramble);
	DataBT sixScramble = new DataBT(6, threeScramble, fourScramble);
	DataBT fiveScramble2 = new DataBT(5, sixScramble, mtBT);
	
	MtHeap mtHeap = new MtHeap();
	DataHeap fourHeap = new DataHeap(4);
	DataHeap sixHeap = new DataHeap(6);
	DataHeap fiveHeap = new DataHeap(5);
	DataHeap sevenHeap = new DataHeap(7);
	DataHeap twoHeap = new DataHeap(2, fourHeap, sixHeap);
	DataHeap threeHeap = new DataHeap(3, fiveHeap, sevenHeap);
	DataHeap oneHeap = new DataHeap(1, twoHeap, threeHeap);
	
	DataBT sixRemoved = new DataBT(6);
	DataBT fiveRemoved = new DataBT(5);
	DataBT sevenRemoved = new DataBT(7);
	DataBT fourRemoved = new DataBT(4, sixRemoved, mtBT);
	DataBT threeRemoved = new DataBT(3, fiveRemoved, sevenRemoved);
	DataBT twoRemoved = new DataBT(2, fourRemoved, threeRemoved);
	
	DataBT eight = new DataBT(8);
	DataBT ten = new DataBT(10, eight, mtBT);
	
	DataBT eleven1 = new DataBT(11);
	DataBT eleven2 = new DataBT(11, eleven1, mtBT);
	
	DataBT fourAdded = new DataBT(4);
	DataBT sixAdded = new DataBT(6);
	DataBT fiveAdded = new DataBT(5);
	DataBT sevenAdded = new DataBT(7);
	DataBT fiveAddedElt = new DataBT(5, mtBT, sevenAdded);
	DataBT twoAdded = new DataBT(2, fourAdded, sixAdded);
	DataBT threeAdded = new DataBT(3, fiveAdded, fiveAddedElt);
	DataBT oneAdded = new DataBT(1, twoAdded, threeAdded);
	
	DataBT fiveThirdElt = new DataBT(5);
	DataBT fourAdded2 = new DataBT(4, fiveThirdElt, mtBT);
	DataBT sixAdded2 = new DataBT(6);
	DataBT fiveAdded2 = new DataBT(5);
	DataBT sevenAdded2 = new DataBT(7);
	DataBT fiveAddedElt2 = new DataBT(5, mtBT, sevenAdded2);
	DataBT twoAdded2 = new DataBT(2, fourAdded2, sixAdded2);
	DataBT threeAdded2 = new DataBT(3, fiveThirdElt, fiveAddedElt2);
	DataBT oneAdded2 = new DataBT(1, twoAdded2, threeAdded2);
	
	DataHeap fourAddedHeap = new DataHeap(4);
	DataHeap sixAddedHeap = new DataHeap(6);
	DataHeap fiveAddedHeap = new DataHeap(5);
	DataHeap sevenAddedHeap = new DataHeap(7);
	DataHeap fiveAddedEltHeap = new DataHeap(5, mtHeap, sevenAddedHeap);
	DataHeap twoAddedHeap = new DataHeap(2, fourAddedHeap, sixAddedHeap);
	DataHeap threeAddedHeap = new DataHeap(3, fiveAddedHeap, fiveAddedEltHeap);
	DataHeap oneAddedHeap = new DataHeap(1, twoAddedHeap, threeAddedHeap);
	
	
	
	@Test
	public void addEltTesterTrue() {
		assertTrue(HT.addEltTester(oneHeap, 5, oneHeap.addElt(5)));
	}
	
	@Test
	public void addEltTesterTrueDuplicateElements() {
		assertTrue(HT.addEltTester(oneAddedHeap, 5, oneAddedHeap.addElt(5)));
	}
	
	@Test
	public void addEltTesterTrueEmptyHeap() {
		assertTrue(HT.addEltTester(mtHeap, 5, mtHeap.addElt(5)));
	}
	
	@Test
	public void addEltTesterFalseEmptyBT() {
		assertFalse(HT.addEltTester(mtHeap, 5, mtBT));
	}
	
	@Test
	public void addEltTesterFalseNotHeap() {
		assertFalse(HT.addEltTester(oneHeap, 5, fiveScramble2));
	}
	
	@Test
	public void addEltTesterFalseDoesntContainAllElements() {
		DataHeap eightHeap = new DataHeap(8);
		DataHeap fourHeap = new DataHeap(4, eightHeap, mtHeap);
		DataHeap sixHeap = new DataHeap(6);
		DataHeap fiveHeap = new DataHeap(5);
		DataHeap sevenHeap = new DataHeap(7);
		DataHeap twoHeap = new DataHeap(2, fourHeap, sixHeap);
		DataHeap threeHeap = new DataHeap(3, fiveHeap, sevenHeap);
		DataHeap oneHeap = new DataHeap(1, twoHeap, threeHeap);
		assertFalse(HT.addEltTester(oneHeap, 5, oneAdded));
	}
	
	@Test
	public void addEltTesterFalseHasNotBeenAdded() {
		assertFalse(HT.addEltTester(oneHeap, 5, one));
	}
	
	@Test
	public void addEltTesterFalseNewElements() {
		DataBT eightAdded = new DataBT(8);
		DataBT fourAdded = new DataBT(4, eightAdded, mtBT);
		DataBT sixAdded = new DataBT(6);
		DataBT fiveAdded = new DataBT(5);
		DataBT sevenAdded = new DataBT(7);
		DataBT fiveAddedElt = new DataBT(5, mtBT, sevenAdded);
		DataBT twoAdded = new DataBT(2, fourAdded, sixAdded);
		DataBT threeAdded = new DataBT(3, fiveAdded, fiveAddedElt);
		DataBT oneAdded = new DataBT(1, twoAdded, threeAdded);
		assertFalse(HT.addEltTester(oneHeap, 5, oneAdded));
	}
	
	@Test
	public void remMinEltTesterTrue() {
		assertTrue(HT.remMinEltTester(oneHeap, twoRemoved));
	}
	
	@Test
	public void remMinEltTesterTrueDuplicateElements() {
		DataHeap three = new DataHeap(3);
		DataHeap four2 = new DataHeap(4);
		DataHeap five = new DataHeap(5);
		DataHeap four1 = new DataHeap(4, five, mtHeap);
		DataHeap two = new DataHeap(2, four2, three);
		DataHeap one = new DataHeap(1, two, four1);
		
		
		DataBT fiveRemoved = new DataBT(5);
		DataBT four1Removed = new DataBT(4);
		DataBT four2Removed = new DataBT(4, fiveRemoved, mtBT);
		DataBT threeRemoved = new DataBT(3, four1Removed, mtBT);
		DataBT twoRemoved = new DataBT(2, threeRemoved, four2Removed);
		
		assertTrue(HT.remMinEltTester(one, twoRemoved));
	}
	
	@Test
	public void remMinEltTesterTrueEmptyBTAndHeap() {
		assertTrue(HT.remMinEltTester(mtHeap, mtBT));
	}
	
	@Test
	public void remMinEltTesterTrueEmptyBT() {
		assertTrue(HT.remMinEltTester(fiveHeap, mtBT));
	}
	
	@Test
	public void remMinEltTesterFalseEmptyHeap() {
		assertFalse(HT.remMinEltTester(mtHeap, five));
	}
	
	@Test
	public void remMinEltTesterFalseNotHeap() {
		
		DataBT threeRemoved = new DataBT(3);
		DataBT fiveRemoved = new DataBT(5);
		DataBT sevenRemoved = new DataBT(7);
		DataBT sixRemoved = new DataBT(6, fiveRemoved, sevenRemoved);
		DataBT fourRemoved = new DataBT(4, sixRemoved, mtBT);
		DataBT twoRemoved = new DataBT(2, fourRemoved, threeRemoved); 
		assertFalse(HT.remMinEltTester(oneHeap, twoRemoved));
	}
	
	@Test
	public void remMinEltTesterFalseDoesntContainAllElements() {
		DataHeap eightHeap = new DataHeap(8);
		DataHeap fourHeap = new DataHeap(4, eightHeap, mtHeap);
		DataHeap sixHeap = new DataHeap(6);
		DataHeap fiveHeap = new DataHeap(5);
		DataHeap sevenHeap = new DataHeap(7);
		DataHeap twoHeap = new DataHeap(2, fourHeap, sixHeap);
		DataHeap threeHeap = new DataHeap(3, fiveHeap, sevenHeap);
		DataHeap oneHeap = new DataHeap(1, twoHeap, threeHeap);
		assertFalse(HT.remMinEltTester(oneHeap, twoRemoved));
	}
	
	@Test
	public void remMinEltTesterFalseHasNotBeenRemoved() {
		assertFalse(HT.remMinEltTester(oneHeap, one));
	}
	
	@Test
	public void remMinEltTesterFalseNewElements() {
		DataBT eightRemoved = new DataBT(8);
		DataBT sixRemoved = new DataBT(6, eightRemoved, mtBT);
		DataBT fiveRemoved = new DataBT(5);
		DataBT sevenRemoved = new DataBT(7);
		DataBT fourRemoved = new DataBT(4, sixRemoved, mtBT);
		DataBT threeRemoved = new DataBT(3, fiveRemoved, sevenRemoved);
		DataBT twoRemoved = new DataBT(2, fourRemoved, threeRemoved);
		assertFalse(HT.remMinEltTester(oneHeap, twoRemoved));
	}
	
    
}
