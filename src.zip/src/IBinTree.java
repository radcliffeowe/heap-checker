import java.lang.Math;
import java.util.LinkedList;

interface IBinTree {
	// determines whether element is in the tree
	boolean hasElt(int e);
	// returns number of nodes in the tree; counts duplicate elements as separate items
	int size();
	// returns depth of longest branch in the tree
	int height();

	boolean isHeap(int root, IBinTree hAdded);

	int countOccurences(int e);

	boolean containsAllElements(IHeap hOriginal, int elt, IBinTree hAdded);

	LinkedList<Integer> extractData(LinkedList<Integer> data);
	
	boolean hasBeenAdded(IHeap hOriginal, int elt, IBinTree hAdded);
	
	boolean hasBeenRemoved(IHeap hOriginal, IBinTree hAdded);
	
	boolean noNewElements(IHeap hOriginal, int elt, IBinTree hAdded);
	
	boolean containsAllElementsRemoved(IHeap hOriginal, IBinTree hAdded);
	
	boolean noNewElementsRemoved(IHeap hOriginal, IBinTree hAdded);
	
	
}
